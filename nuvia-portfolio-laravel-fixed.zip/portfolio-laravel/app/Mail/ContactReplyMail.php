<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ContactReplyMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public string $body) {}

    public function build(): static
    {
        return $this->subject('Reply to your portfolio message')
            ->html('<div style="font-family:system-ui,sans-serif;line-height:1.6;white-space:pre-wrap">'.e($this->body).'</div>');
    }
}
