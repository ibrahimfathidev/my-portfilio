<?php

namespace App\Http\Controllers;

use App\Models\Achievement;
use App\Models\AiRequest;
use App\Models\BlogPost;
use App\Models\ContactMessage;
use App\Models\Integration;
use App\Models\LabItem;
use App\Models\Language;
use App\Models\Project;
use App\Models\ProjectArtifact;
use App\Models\SiteSetting;
use App\Models\SocialLink;
use App\Models\Stack;
use App\Models\ThoughtPost;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Inertia\Inertia;

class AdminController extends Controller
{
    private const RESOURCES = [
        'projects' => Project::class,
        'artifacts' => ProjectArtifact::class,
        'social_links' => SocialLink::class,
        'achievements' => Achievement::class,
        'stacks' => Stack::class,
        'integrations' => Integration::class,
        'languages' => Language::class,
        'lab' => LabItem::class,
        'blog_posts' => BlogPost::class,
        'thought_posts' => ThoughtPost::class,
        'settings' => SiteSetting::class,
    ];

    public function dashboard()
    {
        $payload = [];
        foreach (self::RESOURCES as $name => $class) {
            $payload[$name] = $class::query()->orderBy('id')->get();
        }
        $payload['contact_messages'] = ContactMessage::query()->latest()->get();
        $payload['ai_requests'] = AiRequest::query()->latest()->limit(100)->get();

        return Inertia::render('Admin/Dashboard', ['data' => $payload, 'resources' => array_keys(self::RESOURCES)]);
    }

    public function store(Request $request, string $resource)
    {
        $model = $this->model($resource);
        $data = $this->validateResource($request, $resource);
        $record = $model::create($data);

        return response()->json(['data' => $record]);
    }

    public function update(Request $request, string $resource, int $id)
    {
        $model = $this->model($resource);
        $record = $model::query()->findOrFail($id);
        $record->update($this->validateResource($request, $resource, $record));

        return response()->json(['data' => $record->fresh()]);
    }

    public function destroy(string $resource, int $id)
    {
        $model = $this->model($resource);
        $record = $model::query()->findOrFail($id);
        $record->delete();

        return response()->json(['ok' => true]);
    }

    public function updateContact(Request $request, ContactMessage $contactMessage)
    {
        $data = $request->validate(['status' => ['required', 'in:new,read,replied,archived']]);
        $contactMessage->update($data);

        return response()->json(['data' => $contactMessage]);
    }

    private function model(string $resource): string
    {
        abort_unless(isset(self::RESOURCES[$resource]), 404);

        return self::RESOURCES[$resource];
    }

    private function validateResource(Request $request, string $resource, ?Model $record = null): array
    {
        $rules = match ($resource) {
            'projects' => [
                'title' => ['required', 'string', 'max:180'], 'slug' => ['required', 'string', 'max:180'], 'description' => ['nullable', 'string'],
                'thumbnail_url' => ['nullable', 'string', 'max:5000'], 'thumbnail_data' => ['nullable', 'string'], 'live_url' => ['nullable', 'url', 'max:1000'],
                'github_url' => ['nullable', 'url', 'max:1000'], 'visibility' => ['required', 'in:open_source,closed_source'], 'tags' => ['nullable', 'array'],
                'sort_order' => ['integer'], 'featured' => ['boolean'], 'is_published' => ['boolean'],
            ],
            'artifacts' => [
                'project_id' => ['nullable', 'integer', 'exists:projects,id'], 'type' => ['required', 'in:problem_solving,architecture,erd,flow_chart'],
                'title' => ['required', 'string', 'max:180'], 'description' => ['nullable', 'string'], 'content' => ['nullable', 'string'],
                'image_url' => ['nullable', 'string', 'max:5000'], 'image_data' => ['nullable', 'string'], 'sort_order' => ['integer'], 'is_published' => ['boolean'],
            ],
            'social_links' => ['platform' => ['required', 'string', 'max:80'], 'label' => ['nullable', 'string', 'max:120'], 'url' => ['required', 'url', 'max:1000'], 'icon' => ['nullable', 'string'], 'sort_order' => ['integer'], 'is_visible' => ['boolean']],
            'achievements' => ['type' => ['required', 'in:certificate,competition,hackathon'], 'title' => ['required', 'string', 'max:180'], 'organization' => ['nullable', 'string', 'max:180'], 'description' => ['nullable', 'string'], 'achieved_at' => ['nullable', 'date'], 'credential_url' => ['nullable', 'url', 'max:1000'], 'image_url' => ['nullable', 'string', 'max:5000'], 'image_data' => ['nullable', 'string'], 'sort_order' => ['integer'], 'is_visible' => ['boolean']],
            'stacks' => ['name' => ['required', 'string', 'max:100'], 'category' => ['nullable', 'string', 'max:100'], 'url' => ['nullable', 'url', 'max:1000'], 'icon' => ['nullable', 'string'], 'sort_order' => ['integer'], 'is_visible' => ['boolean']],
            'integrations' => ['name' => ['required', 'string', 'max:100'], 'category' => ['nullable', 'string', 'max:100'], 'url' => ['nullable', 'url', 'max:1000'], 'description' => ['nullable', 'string'], 'icon' => ['nullable', 'string'], 'sort_order' => ['integer'], 'is_visible' => ['boolean']],
            'languages' => ['name' => ['required', 'string', 'max:100'], 'level' => ['nullable', 'string', 'max:100'], 'proficiency' => ['nullable', 'integer', 'min:0', 'max:100'], 'sort_order' => ['integer'], 'is_visible' => ['boolean']],
            'lab' => ['title' => ['required', 'string', 'max:180'], 'description' => ['nullable', 'string'], 'progress' => ['integer', 'min:0', 'max:100'], 'status' => ['required', 'in:idea,in_progress,paused,done'], 'url' => ['nullable', 'url', 'max:1000'], 'started_at' => ['nullable', 'date'], 'updated_progress_at' => ['nullable', 'date'], 'sort_order' => ['integer'], 'is_visible' => ['boolean']],
            'blog_posts' => ['title' => ['required', 'string', 'max:180'], 'slug' => ['required', 'string', 'max:180'], 'description' => ['nullable', 'string'], 'content' => ['nullable', 'string'], 'image_data' => ['nullable', 'string'], 'image_url' => ['nullable', 'string', 'max:5000'], 'published_at' => ['nullable', 'date'], 'is_published' => ['boolean'], 'sort_order' => ['integer']],
            'thought_posts' => ['title' => ['required', 'string', 'max:180'], 'slug' => ['required', 'string', 'max:180'], 'description' => ['nullable', 'string'], 'content' => ['nullable', 'string'], 'published_at' => ['nullable', 'date'], 'is_published' => ['boolean'], 'sort_order' => ['integer']],
            'settings' => ['key' => ['required', 'string', 'max:120'], 'value' => ['nullable', 'string'], 'type' => ['required', 'in:text,textarea,json,url,email']],
            default => [],
        };

        return $request->validate($rules);
    }
}
