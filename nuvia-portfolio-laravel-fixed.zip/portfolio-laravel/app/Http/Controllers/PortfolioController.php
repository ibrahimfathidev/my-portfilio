<?php

namespace App\Http\Controllers;

use App\Models\BlogPost;
use App\Models\ThoughtPost;
use App\Services\PortfolioData;
use Inertia\Inertia;

class PortfolioController extends Controller
{
    public function index(PortfolioData $data)
    {
        return Inertia::render('Home', [
            'portfolio' => $data->public(),
        ]);
    }

    public function blog(string $slug)
    {
        $post = BlogPost::query()->where('slug', $slug)->where('is_published', true)->firstOrFail();

        return Inertia::render('BlogShow', ['post' => $post]);
    }

    public function thinking(string $slug)
    {
        $post = ThoughtPost::query()->where('slug', $slug)->where('is_published', true)->firstOrFail();

        return Inertia::render('ThinkingShow', ['post' => $post]);
    }
}
