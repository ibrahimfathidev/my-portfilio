<?php

namespace App\Http\Controllers;

use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->validate([
            'type' => ['required', 'in:hiring,contract,question'],
            'title' => ['required', 'string', 'max:180'],
            'name' => ['nullable', 'string', 'max:120'],
            'email' => ['required', 'email', 'max:255'],
            'message' => ['required', 'string', 'max:10000'],
        ]);

        $data['ip_hash'] = hash_hmac('sha256', (string) $request->ip(), (string) config('app.key'));
        $message = ContactMessage::create($data);

        try {
            Mail::raw("New portfolio contact #{$message->id}\n\n{$message->message}", function ($mail) use ($message) {
                $mail->to(env('ADMIN_EMAIL'))
                    ->subject("Portfolio contact: {$message->title}");
            });
        } catch (\Throwable) {
            // Message is already stored; email delivery can be retried from admin.
        }

        return response()->json(['ok' => true, 'message' => 'Thanks. Your message has been received.']);
    }

    public function reply(Request $request, ContactMessage $contactMessage)
    {
        $data = $request->validate(['admin_reply' => ['required', 'string', 'max:20000']]);

        $contactMessage->update([
            'admin_reply' => $data['admin_reply'],
            'replied_at' => now(),
            'status' => 'replied',
        ]);

        Mail::raw($data['admin_reply'], function ($mail) use ($contactMessage) {
            $mail->to($contactMessage->email)->replyTo(env('MAIL_FROM_ADDRESS'))->subject('Reply to your portfolio message');
        });

        return response()->json(['ok' => true]);
    }
}
