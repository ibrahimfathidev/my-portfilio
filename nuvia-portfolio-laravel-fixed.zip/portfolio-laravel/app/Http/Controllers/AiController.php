<?php

namespace App\Http\Controllers;

use App\Models\AiRequest;
use App\Services\AiWorker;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AiController extends Controller
{
    public function ask(Request $request, AiWorker $worker)
    {
        $data = $request->validate([
            'prompt' => ['required', 'string', 'max:5000'],
            'name' => ['nullable', 'string', 'max:120'],
            'email' => ['nullable', 'email', 'max:255'],
            'session_id' => ['nullable', 'string', 'max:120'],
        ]);

        $started = microtime(true);
        $row = AiRequest::create([
            ...$data,
            'status' => 'processing',
            'ip_hash' => hash_hmac('sha256', (string) $request->ip(), (string) config('app.key')),
        ]);

        try {
            $answer = $worker->ask($data['prompt'], $data['email'] ?? null);
            $row->update([
                'response' => $answer,
                'status' => 'completed',
                'duration_ms' => (int) round((microtime(true) - $started) * 1000),
            ]);

            return response()->json(['ok' => true, 'response' => $answer, 'request_id' => $row->id]);
        } catch (\Throwable $e) {
            $row->update([
                'response' => 'The AI assistant is temporarily unavailable.',
                'status' => 'failed',
                'duration_ms' => (int) round((microtime(true) - $started) * 1000),
                'metadata' => ['error' => Str::limit($e->getMessage(), 500)],
            ]);

            return response()->json(['ok' => false, 'message' => 'The AI assistant is temporarily unavailable.'], 502);
        }
    }
}
