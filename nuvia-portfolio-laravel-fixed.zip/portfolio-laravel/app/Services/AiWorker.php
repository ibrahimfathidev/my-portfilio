<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use RuntimeException;

class AiWorker
{
    public function ask(string $prompt, ?string $email = null): string
    {
        $url = config('services.ai_worker.url');
        if (! $url) {
            throw new RuntimeException('AI worker is not configured.');
        }

        $response = Http::timeout((int) config('services.ai_worker.timeout', 25))
            ->acceptJson()
            ->asJson()
            ->post($url, [
                'message' => $prompt,
                'email' => $email,
                'source' => 'portfolio',
            ]);

        $response->throw();
        $json = $response->json();

        return (string) ($json['response'] ?? $json['message'] ?? $json['text'] ?? 'No response returned.');
    }
}
