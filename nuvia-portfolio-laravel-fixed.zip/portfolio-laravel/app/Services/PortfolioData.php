<?php

namespace App\Services;

use App\Models\Achievement;
use App\Models\BlogPost;
use App\Models\Integration;
use App\Models\LabItem;
use App\Models\Language;
use App\Models\Project;
use App\Models\ProjectArtifact;
use App\Models\SiteSetting;
use App\Models\SocialLink;
use App\Models\Stack;
use App\Models\ThoughtPost;

class PortfolioData
{
    public function public(): array
    {
        return [
            'settings' => SiteSetting::query()->get()->pluck('value', 'key'),
            'projects' => Project::query()->where('is_published', true)->orderBy('sort_order')->get(),
            'artifacts' => ProjectArtifact::query()->where('is_published', true)->orderBy('sort_order')->get(),
            'social_links' => SocialLink::query()->where('is_visible', true)->orderBy('sort_order')->get(),
            'achievements' => Achievement::query()->where('is_visible', true)->orderByDesc('achieved_at')->orderBy('sort_order')->get(),
            'stacks' => Stack::query()->where('is_visible', true)->orderBy('sort_order')->get(),
            'integrations' => Integration::query()->where('is_visible', true)->orderBy('sort_order')->get(),
            'languages' => Language::query()->where('is_visible', true)->orderBy('sort_order')->get(),
            'lab' => LabItem::query()->where('is_visible', true)->orderBy('sort_order')->get(),
            'blog_posts' => BlogPost::query()->where('is_published', true)->orderByDesc('published_at')->orderBy('sort_order')->get(),
            'thought_posts' => ThoughtPost::query()->where('is_published', true)->orderByDesc('published_at')->orderBy('sort_order')->get(),
        ];
    }
}
