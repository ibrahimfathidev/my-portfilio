import React, { useState } from 'react';
import { api } from '../http';

export default function ContactForm() {
  const [form, setForm] = useState({ type: 'question', title: '', name: '', email: '', message: '' });
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState('');

  function change(key: string, value: string) { setForm(f => ({ ...f, [key]: value })); }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setSent('');
    try {
      const data = await api<{ message: string }>('/contact', { method: 'POST', body: JSON.stringify(form) });
      setSent(data.message);
      setForm({ type: 'question', title: '', name: '', email: '', message: '' });
    } catch (err) {
      setSent(err instanceof Error ? err.message : 'Unable to send your message.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="contact-form">
      <div className="form-grid">
        <label>Reason<select value={form.type} onChange={e => change('type', e.target.value)}><option value="hiring">Hiring</option><option value="contract">Contract</option><option value="question">Just a question</option></select></label>
        <label>Title<input value={form.title} onChange={e => change('title', e.target.value)} required /></label>
        <label>Name<input value={form.name} onChange={e => change('name', e.target.value)} /></label>
        <label>Email<input value={form.email} onChange={e => change('email', e.target.value)} type="email" required /></label>
      </div>
      <label>Message<textarea value={form.message} onChange={e => change('message', e.target.value)} rows={7} required /></label>
      <div className="form-actions"><button className="button" disabled={busy}>{busy ? 'Sending…' : 'Send message'}</button>{sent && <span className="muted">{sent}</span>}</div>
    </form>
  );
}
