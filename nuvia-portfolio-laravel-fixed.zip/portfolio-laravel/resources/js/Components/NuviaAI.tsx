import React, { useState } from 'react';
import { api } from '../http';

export default function NuviaAI() {
  const [prompt, setPrompt] = useState('');
  const [answer, setAnswer] = useState('');
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!prompt.trim()) return;
    setBusy(true);
    try {
      const data = await api<{ response: string }>('/ai/ask', {
        method: 'POST',
        body: JSON.stringify({ prompt, email: email || undefined }),
      });
      setAnswer(data.response);
      setPrompt('');
    } catch (err) {
      setAnswer(err instanceof Error ? err.message : 'Something went wrong.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="ai-box">
      <div>
        <div className="eyebrow">Need Help?</div>
        <h3>Talk with Nuvia AI</h3>
        <p>Ask about projects, stack choices, architecture, or how to work together.</p>
      </div>
      <form onSubmit={submit} className="ai-form">
        <input value={email} onChange={e => setEmail(e.target.value)} type="email" placeholder="Your email (optional)" />
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Ask Nuvia AI something…" rows={4} />
        <button className="button" disabled={busy}>{busy ? 'Thinking…' : 'Ask Nuvia AI'}</button>
      </form>
      {answer && <div className="answer"><div className="eyebrow">Nuvia AI</div><div>{answer}</div></div>}
    </div>
  );
}
