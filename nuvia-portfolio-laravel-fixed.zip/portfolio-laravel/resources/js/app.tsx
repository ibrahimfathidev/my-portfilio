import '../css/app.css';
import './register-sw';
import { createInertiaApp } from '@inertiajs/react';
import { createRoot } from 'react-dom/client';
import React from 'react';

const pages = import.meta.glob('./Pages/**/*.tsx', { eager: true });

createInertiaApp({
  resolve: name => {
    const page = pages[`./Pages/${name}.tsx`] as { default: React.ComponentType<any> } | undefined;
    if (!page) throw new Error(`Page not found: ${name}`);
    return page.default;
  },
  setup({ el, App, props }) {
    createRoot(el).render(<App {...props} />);
  },
  progress: { color: '#a7f3d0' },
});
