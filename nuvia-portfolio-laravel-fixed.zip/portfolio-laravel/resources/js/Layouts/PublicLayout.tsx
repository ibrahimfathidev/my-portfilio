import React from 'react';
import { Link } from '@inertiajs/react';

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="site-shell">
      <header className="nav">
        <Link href="/" className="brand">Nuvia<span>.</span></Link>
        <nav>
          <a href="/#projects">Projects</a>
          <a href="/#lab">Lab</a>
          <a href="/#blog">Blog</a>
          <a href="/#contact">Contact</a>
        </nav>
        <a className="button small" href="/#contact">Let’s talk</a>
      </header>
      {children}
      <footer className="footer"><span>Built with Laravel + React + Supabase.</span><a href="/admin/login">Admin</a></footer>
    </div>
  );
}
