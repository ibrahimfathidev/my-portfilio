import React from 'react';
import { Head, Link } from '@inertiajs/react';
import PublicLayout from '../Layouts/PublicLayout';
import Section from '../Components/Section';
import Card from '../Components/Card';
import NuviaAI from '../Components/NuviaAI';
import ContactForm from '../Components/ContactForm';
import { Portfolio } from '../types';

function imageFor(item: any) { return item.thumbnail_data || item.thumbnail_url || item.image_data || item.image_url; }

export default function Home({ portfolio }: { portfolio: Portfolio }) {
  const settings = portfolio.settings ?? {};
  const open = portfolio.projects.filter((p: any) => p.visibility === 'open_source');
  const closed = portfolio.projects.filter((p: any) => p.visibility === 'closed_source');

  return (
    <PublicLayout>
      <Head title={settings.hero_title || 'Portfolio'}><meta name="description" content={settings.hero_description || 'Portfolio and lab'} /></Head>
      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow">{settings.hero_eyebrow || 'Software engineering · AI · Data'}</div>
            <h1>{settings.hero_title || 'I build useful systems, products, and experiments.'}</h1>
            <p>{settings.hero_description || 'A living portfolio covering open-source projects, private work, engineering notes, and an active lab.'}</p>
            <div className="hero-actions"><a className="button" href="#projects">Explore projects</a><a className="button ghost" href="#contact">Contact</a></div>
          </div>
          <aside className="hero-note"><div className="eyebrow">Vision</div><p>{settings.vision || 'Build systems that are simple to understand, resilient in production, and useful to real people.'}</p><div className="stamp">Live · Editable · Experimental</div></aside>
        </section>

        <Section id="projects" eyebrow="Projects" title="Open source">
          <div className="grid three">
            {open.map(p => <Card key={p.id}>{imageFor(p) && <img className="thumb" src={imageFor(p)} alt="" />}<div className="card-body"><div className="card-kicker">Open source</div><h3>{p.title}</h3><p>{p.description}</p><div className="links">{p.live_url && <a href={p.live_url} target="_blank">Live</a>}{p.github_url && <a href={p.github_url} target="_blank">GitHub</a>}</div></div></Card>)}
            {open.length === 0 && <Card><p className="muted">Add open-source projects from the admin page.</p></Card>}
          </div>
        </Section>

        <Section id="private-projects" eyebrow="Projects" title="Closed source">
          <div className="grid three">
            {closed.map(p => <Card key={p.id}>{imageFor(p) && <img className="thumb" src={imageFor(p)} alt="" />}<div className="card-body"><div className="card-kicker">Closed source</div><h3>{p.title}</h3><p>{p.description}</p>{p.live_url && <a className="inline-link" href={p.live_url} target="_blank">Live ↗</a>}</div></Card>)}
            {closed.length === 0 && <Card><p className="muted">Add private work from the admin page.</p></Card>}
          </div>
        </Section>

        <Section id="social" eyebrow="Social" title="Find me online">
          <div className="chips">{portfolio.social_links.map(s => <a key={s.id} className="chip" href={s.url} target="_blank">{s.label || s.platform}</a>)}</div>
        </Section>

        <Section id="achievements" eyebrow="Achievements" title="Certificates, competitions & hackathons">
          <div className="grid two">{portfolio.achievements.map(a => <Card key={a.id}><div className="card-kicker">{a.type}</div><h3>{a.title}</h3><p>{a.description}</p><div className="muted">{a.organization}</div>{a.credential_url && <a className="inline-link" href={a.credential_url} target="_blank">Credential ↗</a>}</Card>)}</div>
        </Section>

        <Section id="how-i-think" eyebrow="How I Think" title="Problem solving & project architecture">
          <div className="grid three">{portfolio.artifacts.map(a => <Card key={a.id}><div className="card-kicker">{a.type.replace('_',' ')}</div><h3>{a.title}</h3><p>{a.description}</p>{a.content && <pre className="code-card">{a.content}</pre>}{imageFor(a) && <img className="artifact-image" src={imageFor(a)} alt="" />}</Card>)}</div>
        </Section>

        <Section id="stack" eyebrow="Stack" title="Tools I use">
          <div className="stack-grid">{portfolio.stacks.map(s => <div className="stack-item" key={s.id}><strong>{s.name}</strong><span>{s.category}</span></div>)}</div>
        </Section>

        <Section id="integrations" eyebrow="Integrations" title="Shipping & infrastructure">
          <div className="grid three">{portfolio.integrations.map(i => <Card key={i.id}><h3>{i.name}</h3><div className="muted">{i.category}</div><p>{i.description}</p>{i.url && <a className="inline-link" href={i.url} target="_blank">Open ↗</a>}</Card>)}</div>
        </Section>

        <Section id="lab" eyebrow="LAB" title="Current projects & progress">
          <div className="lab-grid">{portfolio.lab.map(item => <Card key={item.id}><div className="lab-top"><h3>{item.title}</h3><span>{item.progress}%</span></div><p>{item.description}</p><div className="progress"><span style={{ width: `${item.progress}%` }} /></div><div className="muted">{item.status}</div>{item.url && <a className="inline-link" href={item.url} target="_blank">Lab item ↗</a>}</Card>)}</div>
        </Section>

        <Section id="blog" eyebrow="Daily Blog" title="Writing">
          <div className="grid two">{portfolio.blog_posts.map(post => <Card key={post.id}>{post.image_data && <img className="thumb" src={post.image_data} alt="" />}<div className="card-body"><h3>{post.title}</h3><p>{post.description}</p><Link className="inline-link" href={`/blog/${post.slug}`}>Read ↗</Link></div></Card>)}</div>
        </Section>

        <Section id="languages" eyebrow="Languages" title="Communication">
          <div className="language-grid">{portfolio.languages.map(l => <div key={l.id} className="language"><strong>{l.name}</strong><span>{l.level}</span>{l.proficiency != null && <div className="progress"><span style={{ width: `${l.proficiency}%` }}/></div>}</div>)}</div>
        </Section>

        <section className="section split">
          <NuviaAI />
          <div id="contact" className="contact-box"><div className="eyebrow">Contact</div><h2>{settings.contact_title || 'Let’s build something.'}</h2><p>{settings.contact_description || 'Hiring, contract, or just a question — send a message and I’ll send the response to your email.'}</p><ContactForm /></div>
        </section>
      </main>
    </PublicLayout>
  );
}
