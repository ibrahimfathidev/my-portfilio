import React, { useMemo, useState } from 'react';
import { Head, router } from '@inertiajs/react';
import { api } from '../../http';

type Row = Record<string, any> & { id: number };

type Props = { data: Record<string, Row[]>; resources: string[] };

function strip(row: Row) {
  const { id: _id, created_at: _createdAt, updated_at: _updatedAt, ...copy } = row;
  return copy;
}

function ResourcePanel({ name, rows, onRefresh }: { name: string; rows: Row[]; onRefresh: () => void }) {
  const [selected, setSelected] = useState<number | null>(rows[0]?.id ?? null);
  const [text, setText] = useState(rows[0] ? JSON.stringify(strip(rows[0]), null, 2) : '{}');
  const [busy, setBusy] = useState(false);

  function select(row: Row) { setSelected(row.id); setText(JSON.stringify(strip(row), null, 2)); }
  function reset() { setSelected(null); setText('{}'); }

  async function save() {
    setBusy(true);
    try {
      const body = JSON.parse(text);
      if (selected) await api(`/admin/resource/${name}/${selected}`, { method: 'PUT', body: JSON.stringify(body) });
      else await api(`/admin/resource/${name}`, { method: 'POST', body: JSON.stringify(body) });
      onRefresh();
    } catch (e) { alert(e instanceof Error ? e.message : 'Invalid JSON or request'); }
    finally { setBusy(false); }
  }

  async function remove() {
    if (!selected || !confirm(`Delete ${name} #${selected}?`)) return;
    setBusy(true);
    try { await api(`/admin/resource/${name}/${selected}`, { method: 'DELETE' }); setSelected(null); setText('{}'); onRefresh(); }
    catch (e) { alert(e instanceof Error ? e.message : 'Delete failed'); }
    finally { setBusy(false); }
  }

  return <div className="admin-panel">
    <div className="admin-panel-head"><div><div className="eyebrow">Content manager</div><h2>{name.replaceAll('_', ' ')}</h2></div><button className="button ghost" onClick={reset}>New</button></div>
    <div className="admin-editor">
      <div className="record-list">{rows.length === 0 && <div className="muted">No records yet.</div>}{rows.map(row => <button key={row.id} className={selected === row.id ? 'record selected' : 'record'} onClick={() => select(row)}><strong>#{row.id}</strong><span>{row.title || row.name || row.key || row.platform || `${row.type ?? 'record'}`}</span></button>)}</div>
      <div className="json-editor"><textarea value={text} onChange={e => setText(e.target.value)} spellCheck={false} /><div className="form-actions"><button className="button" onClick={save} disabled={busy}>{busy ? 'Saving…' : selected ? 'Save changes' : 'Create'}</button>{selected && <button className="button danger" onClick={remove} disabled={busy}>Delete</button>}</div></div>
    </div>
    <p className="muted tiny">Edit a record as JSON. Image fields support normal URLs or data:image/... base64 strings.</p>
  </div>;
}

export default function Dashboard({ data: initial, resources }: Props) {
  const [data, setData] = useState(initial);
  const [active, setActive] = useState(resources[0] ?? 'projects');
  const [replyId, setReplyId] = useState<number | null>(null);
  const [reply, setReply] = useState('');
  const [busy, setBusy] = useState(false);

  const stats = useMemo(() => ({
    projects: data.projects?.length ?? 0,
    messages: data.contact_messages?.filter((m: any) => m.status !== 'archived').length ?? 0,
    ai: data.ai_requests?.length ?? 0,
    lab: data.lab?.length ?? 0,
  }), [data]);

  function refresh() { router.reload({ only: ['data'], onSuccess: page => setData((page.props as any).data) }); }

  async function replyTo(message: any) {
    setBusy(true);
    try { await api(`/admin/messages/${message.id}/reply`, { method: 'POST', body: JSON.stringify({ admin_reply: reply }) }); setReplyId(null); setReply(''); refresh(); }
    catch (e) { alert(e instanceof Error ? e.message : 'Reply failed'); }
    finally { setBusy(false); }
  }

  async function setMessageStatus(id: number, status: string) {
    await api(`/admin/messages/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) });
    refresh();
  }

  const rows = data[active] ?? [];

  return <>
    <Head title="Admin dashboard" />
    <div className="admin-shell">
      <header className="admin-nav"><div><div className="eyebrow">Nuvia CMS</div><h1>Admin dashboard</h1></div><div className="admin-actions"><a className="button ghost small" href="/" target="_blank">View site</a><button className="button small" onClick={() => router.post('/admin/logout')}>Log out</button></div></header>
      <main className="admin-main">
        <div className="stat-grid"><div className="stat"><span>Projects</span><strong>{stats.projects}</strong></div><div className="stat"><span>Messages</span><strong>{stats.messages}</strong></div><div className="stat"><span>AI requests</span><strong>{stats.ai}</strong></div><div className="stat"><span>Lab items</span><strong>{stats.lab}</strong></div></div>
        <div className="admin-tabs">{resources.map(r => <button key={r} className={active === r ? 'tab active' : 'tab'} onClick={() => setActive(r)}>{r.replaceAll('_',' ')}</button>)}<button className={active === 'messages' ? 'tab active' : 'tab'} onClick={() => setActive('messages')}>messages</button><button className={active === 'ai_requests' ? 'tab active' : 'tab'} onClick={() => setActive('ai_requests')}>ai requests</button></div>

        {active !== 'messages' && active !== 'ai_requests' && <ResourcePanel name={active} rows={rows} onRefresh={refresh} />}

        {active === 'messages' && <div className="admin-panel"><div className="admin-panel-head"><div><div className="eyebrow">Inbox</div><h2>Contact messages</h2></div></div><div className="message-list">{(data.contact_messages ?? []).map((m: any) => <div className="message-row" key={m.id}><div><div className="message-meta"><strong>#{m.id} · {m.type}</strong><span>{m.status}</span></div><h3>{m.title}</h3><div className="muted">{m.name || 'Anonymous'} · {m.email}</div><p>{m.message}</p>{m.admin_reply && <div className="reply">Reply: {m.admin_reply}</div>}</div><div className="message-actions"><select value={m.status} onChange={e => setMessageStatus(m.id, e.target.value)}><option value="new">new</option><option value="read">read</option><option value="replied">replied</option><option value="archived">archived</option></select><button className="button ghost small" onClick={() => {setReplyId(m.id); setReply(m.admin_reply ?? '')}}>Reply</button></div>{replyId === m.id && <div className="reply-editor"><textarea value={reply} onChange={e => setReply(e.target.value)} rows={5} placeholder="Your email reply…" /><button className="button" disabled={busy} onClick={() => replyTo(m)}>{busy ? 'Sending…' : 'Send reply'}</button></div>}</div>)}{!(data.contact_messages ?? []).length && <div className="muted">No messages.</div>}</div></div>}

        {active === 'ai_requests' && <div className="admin-panel"><div className="admin-panel-head"><div><div className="eyebrow">Nuvia AI</div><h2>AI requests</h2></div></div><div className="message-list">{(data.ai_requests ?? []).map((r: any) => <div className="message-row" key={r.id}><div className="message-meta"><strong>#{r.id} · {r.status}</strong><span>{r.duration_ms ?? '—'} ms</span></div><p><strong>Prompt:</strong> {r.prompt}</p><div className="reply"><strong>Response:</strong> {r.response || '—'}</div></div>)}{!(data.ai_requests ?? []).length && <div className="muted">No AI requests.</div>}</div></div>}
      </main>
    </div>
  </>;
}
