import React, { useState } from 'react';
import { Head, useForm } from '@inertiajs/react';

export default function Login() {
  const { data, setData, post, processing, errors } = useForm({ email: '', password: '', remember: false });
  return <main className="auth-page"><Head title="Admin login" /><form className="auth-card" onSubmit={e => { e.preventDefault(); post('/admin/login'); }}><div className="eyebrow">Private area</div><h1>Admin login</h1><label>Email<input value={data.email} onChange={e => setData('email', e.target.value)} type="email" autoFocus /></label><label>Password<input value={data.password} onChange={e => setData('password', e.target.value)} type="password" /></label><label className="check"><input checked={data.remember} onChange={e => setData('remember', e.target.checked)} type="checkbox" /> Remember me</label>{errors.email && <div className="error">{errors.email}</div>}<button className="button" disabled={processing}>{processing ? 'Signing in…' : 'Sign in'}</button><a href="/">← Public site</a></form></main>;
}
