import React from 'react';
import { Head, Link } from '@inertiajs/react';
import PublicLayout from '../Layouts/PublicLayout';

export default function BlogShow({ post }: { post: any }) {
  return <PublicLayout><Head title={post.title} /><main className="article-page"><Link href="/" className="back">← Back</Link><div className="eyebrow">Daily Blog</div><h1>{post.title}</h1><p className="lead">{post.description}</p>{post.image_data && <img className="article-image" src={post.image_data} alt="" />}<div className="prose">{post.content}</div></main></PublicLayout>;
}
