import React from 'react';
import { Head, Link } from '@inertiajs/react';
import PublicLayout from '../Layouts/PublicLayout';

export default function ThinkingShow({ post }: { post: any }) {
  return <PublicLayout><Head title={post.title} /><main className="article-page"><Link href="/#how-i-think" className="back">← Back</Link><div className="eyebrow">How I Think</div><h1>{post.title}</h1><p className="lead">{post.description}</p><div className="prose">{post.content}</div></main></PublicLayout>;
}
