export type RecordRow = Record<string, any> & { id: number };

export type Portfolio = {
  settings: Record<string, string>;
  projects: RecordRow[];
  artifacts: RecordRow[];
  social_links: RecordRow[];
  achievements: RecordRow[];
  stacks: RecordRow[];
  integrations: RecordRow[];
  languages: RecordRow[];
  lab: RecordRow[];
  blog_posts: RecordRow[];
  thought_posts: RecordRow[];
};
