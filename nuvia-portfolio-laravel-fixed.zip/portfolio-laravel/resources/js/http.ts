export async function api<T = any>(url: string, options: RequestInit = {}): Promise<T> {
  const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ?? '';
  const headers = new Headers(options.headers);
  headers.set('Accept', 'application/json');
  headers.set('X-CSRF-TOKEN', token);
  headers.set('X-Requested-With', 'XMLHttpRequest');
  if (options.body && !(options.body instanceof FormData)) headers.set('Content-Type', 'application/json');

  const response = await fetch(url, { ...options, headers, credentials: 'same-origin' });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message ?? 'Request failed');
  return data;
}
