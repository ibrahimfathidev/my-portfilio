<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AiController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\PortfolioController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PortfolioController::class, 'index'])->name('home');
Route::get('/blog/{slug}', [PortfolioController::class, 'blog'])->name('blog.show');
Route::get('/thinking/{slug}', [PortfolioController::class, 'thinking'])->name('thinking.show');

Route::post('/contact', [ContactController::class, 'store'])->middleware('throttle:6,1')->name('contact.store');
Route::post('/ai/ask', [AiController::class, 'ask'])->middleware('throttle:12,1')->name('ai.ask');

Route::get('/admin/login', [AuthController::class, 'showLogin'])->name('admin.login');
Route::post('/admin/login', [AuthController::class, 'login'])->middleware('throttle:10,1')->name('admin.login.submit');
Route::post('/admin/logout', [AuthController::class, 'logout'])->middleware('auth')->name('admin.logout');

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminController::class, 'dashboard'])->name('dashboard');
    Route::post('/resource/{resource}', [AdminController::class, 'store'])->name('resource.store');
    Route::put('/resource/{resource}/{id}', [AdminController::class, 'update'])->name('resource.update');
    Route::delete('/resource/{resource}/{id}', [AdminController::class, 'destroy'])->name('resource.destroy');
    Route::patch('/messages/{contactMessage}', [AdminController::class, 'updateContact'])->name('message.status');
    Route::post('/messages/{contactMessage}/reply', [ContactController::class, 'reply'])->name('message.reply');
});
