<?php

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

test('home page loads', function () {
    $this->get('/')->assertOk();
});

test('admin login page loads', function () {
    $this->get('/admin/login')->assertOk();
});

test('non admin cannot access dashboard', function () {
    $user = User::factory()->create(['is_admin' => false]);
    $this->actingAs($user)->get('/admin')->assertForbidden();
});
