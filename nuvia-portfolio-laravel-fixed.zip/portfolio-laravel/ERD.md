# ERD — Nuvia Portfolio

```text
users
  └─ is_admin

projects
  └─< project_artifacts

site_settings

social_links
achievements
stacks
integrations
languages
lab_items
blog_posts
thought_posts

contact_messages
ai_requests
```

### Relationships

- `projects.id` → `project_artifacts.project_id` (nullable, delete sets NULL).
- `users` is used for the private admin session and currently has a single `is_admin` boolean.
- The remaining content tables are independent CMS collections ordered with `sort_order` and published/visible flags.
- `contact_messages` and `ai_requests` are append-oriented operational tables for the admin inbox/log.

### Image strategy

`thumbnail_data`, `image_data` are `TEXT`/`LONGTEXT`-style columns intended for data URI base64 images. `thumbnail_url` and `image_url` are also supported. For production at higher volume, move media to Supabase Storage or another object store and retain only URLs in PostgreSQL.
