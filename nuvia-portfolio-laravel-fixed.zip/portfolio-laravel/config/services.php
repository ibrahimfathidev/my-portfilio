<?php

return [
    'ai_worker' => [
        'url' => env('AI_WORKER_URL'),
        'timeout' => (int) env('AI_WORKER_TIMEOUT', 25),
    ],
];
