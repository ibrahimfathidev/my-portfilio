<?php

namespace Database\Seeders;

use App\Models\Achievement;
use App\Models\Integration;
use App\Models\Language;
use App\Models\SiteSetting;
use App\Models\SocialLink;
use App\Models\Stack;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $email = (string) env('ADMIN_EMAIL');
        $password = (string) env('ADMIN_PASSWORD');

        if ($email !== '' && $password !== '' && $password !== 'REPLACE_ME') {
            User::updateOrCreate(
                ['email' => $email],
                ['name' => 'Nuvia Admin', 'password' => $password, 'is_admin' => true]
            );
        }

        $settings = [
            'hero_eyebrow' => ['value' => 'Software engineering · AI · Data', 'type' => 'text'],
            'hero_title' => ['value' => 'I build useful systems, products, and experiments.', 'type' => 'text'],
            'hero_description' => ['value' => 'A living portfolio covering open-source projects, private work, engineering notes, and an active lab.', 'type' => 'textarea'],
            'vision' => ['value' => 'Build systems that are simple to understand, resilient in production, and useful to real people.', 'type' => 'textarea'],
            'contact_title' => ['value' => 'Let’s build something.', 'type' => 'text'],
            'contact_description' => ['value' => 'Hiring, contract, or just a question — send a message and I’ll send the response to your email.', 'type' => 'textarea'],
        ];
        foreach ($settings as $key => $setting) {
            SiteSetting::updateOrCreate(['key' => $key], $setting);
        }

        foreach ([
            ['platform' => 'facebook', 'label' => 'Facebook', 'url' => 'https://facebook.com/', 'sort_order' => 1],
            ['platform' => 'linkedin', 'label' => 'LinkedIn', 'url' => 'https://linkedin.com/', 'sort_order' => 2],
            ['platform' => 'wattpad', 'label' => 'Wattpad', 'url' => 'https://wattpad.com/', 'sort_order' => 3],
            ['platform' => 'reddit', 'label' => 'Reddit', 'url' => 'https://reddit.com/', 'sort_order' => 4],
            ['platform' => 'youtube', 'label' => 'YouTube', 'url' => 'https://youtube.com/', 'sort_order' => 5],
        ] as $row) {
            SocialLink::updateOrCreate(['platform' => $row['platform']], $row);
        }

        foreach (['PHP', 'Laravel', 'React', 'Node.js', 'Next.js', 'Python', 'Automation', 'Web scraping', 'PostgreSQL'] as $i => $name) {
            Stack::updateOrCreate(['name' => $name], ['category' => 'Stack', 'sort_order' => $i + 1, 'is_visible' => true]);
        }

        foreach (['Brevo', 'Supabase', 'Vercel', 'Netlify', 'Cloudflare', 'PWA'] as $i => $name) {
            Integration::updateOrCreate(['name' => $name], ['category' => 'Integration', 'sort_order' => $i + 1, 'is_visible' => true]);
        }

        foreach (['PHP', 'JavaScript', 'TypeScript', 'Python', 'SQL', 'HTML/CSS'] as $i => $name) {
            Language::updateOrCreate(['name' => $name], ['level' => 'Add level', 'sort_order' => $i + 1, 'is_visible' => true]);
        }

        if (Achievement::count() === 0) {
            Achievement::create(['type' => 'certificate', 'title' => 'Add certificate', 'description' => 'Manage certificates, competitions and hackathons here.', 'sort_order' => 1, 'is_visible' => true]);
        }
    }
}
