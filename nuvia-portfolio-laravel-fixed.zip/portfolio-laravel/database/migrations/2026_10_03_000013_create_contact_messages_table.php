<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contact_messages', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['hiring', 'contract', 'question']);
            $table->string('title');
            $table->string('name')->nullable();
            $table->string('email');
            $table->text('message');
            $table->longText('admin_reply')->nullable();
            $table->timestamp('replied_at')->nullable();
            $table->string('status')->default('new');
            $table->string('ip_hash')->nullable();
            $table->timestamps();
            $table->index(['status', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contact_messages');
    }
};
