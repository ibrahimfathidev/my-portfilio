<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->text('thumbnail_url')->nullable();
            $table->longText('thumbnail_data')->nullable();
            $table->string('live_url')->nullable();
            $table->string('github_url')->nullable();
            $table->enum('visibility', ['open_source', 'closed_source'])->default('open_source');
            $table->json('tags')->nullable();
            $table->integer('sort_order')->default(0);
            $table->boolean('featured')->default(false);
            $table->boolean('is_published')->default(true);
            $table->timestamps();
            $table->index(['visibility', 'is_published']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('projects');
    }
};
