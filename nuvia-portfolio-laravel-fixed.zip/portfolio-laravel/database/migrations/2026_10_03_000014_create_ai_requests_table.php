<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_requests', function (Blueprint $table) {
            $table->id();
            $table->string('session_id')->nullable()->index();
            $table->string('name')->nullable();
            $table->string('email')->nullable();
            $table->text('prompt');
            $table->longText('response')->nullable();
            $table->string('status')->default('pending');
            $table->integer('duration_ms')->nullable();
            $table->json('metadata')->nullable();
            $table->string('ip_hash')->nullable();
            $table->timestamps();
            $table->index(['status', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_requests');
    }
};
