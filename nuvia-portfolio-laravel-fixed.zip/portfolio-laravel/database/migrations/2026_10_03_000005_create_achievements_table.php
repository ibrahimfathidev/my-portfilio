<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('achievements', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['certificate', 'competition', 'hackathon']);
            $table->string('title');
            $table->text('organization')->nullable();
            $table->text('description')->nullable();
            $table->date('achieved_at')->nullable();
            $table->string('credential_url')->nullable();
            $table->text('image_url')->nullable();
            $table->longText('image_data')->nullable();
            $table->integer('sort_order')->default(0);
            $table->boolean('is_visible')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('achievements');
    }
};
