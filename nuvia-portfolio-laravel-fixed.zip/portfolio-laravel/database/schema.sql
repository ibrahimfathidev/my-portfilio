-- Nuvia Portfolio schema for Supabase PostgreSQL.
-- This mirrors the Laravel migrations. Prefer `php artisan migrate` for deployment.

create table if not exists users (
  id bigserial primary key,
  name varchar(255) not null,
  email varchar(255) unique not null,
  email_verified_at timestamptz null,
  password varchar(255) not null,
  is_admin boolean not null default false,
  remember_token varchar(100) null,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists projects (
  id bigserial primary key,
  title varchar(255) not null,
  slug varchar(255) unique not null,
  description text,
  thumbnail_url text,
  thumbnail_data text,
  live_url text,
  github_url text,
  visibility varchar(32) not null default 'open_source' check (visibility in ('open_source','closed_source')),
  tags jsonb,
  sort_order integer not null default 0,
  featured boolean not null default false,
  is_published boolean not null default true,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists project_artifacts (
  id bigserial primary key,
  project_id bigint references projects(id) on delete set null,
  type varchar(32) not null check (type in ('problem_solving','architecture','erd','flow_chart')),
  title varchar(255) not null,
  description text,
  content text,
  image_url text,
  image_data text,
  sort_order integer not null default 0,
  is_published boolean not null default true,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists social_links (
  id bigserial primary key,
  platform varchar(100) not null,
  label varchar(120),
  url text not null,
  icon text,
  sort_order integer not null default 0,
  is_visible boolean not null default true,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists achievements (
  id bigserial primary key,
  type varchar(32) not null check (type in ('certificate','competition','hackathon')),
  title varchar(255) not null,
  organization text,
  description text,
  achieved_at date,
  credential_url text,
  image_url text,
  image_data text,
  sort_order integer not null default 0,
  is_visible boolean not null default true,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists stacks (
  id bigserial primary key,
  name varchar(100) unique not null,
  category varchar(100),
  url text,
  icon text,
  sort_order integer not null default 0,
  is_visible boolean not null default true,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists integrations (
  id bigserial primary key,
  name varchar(100) unique not null,
  category varchar(100),
  url text,
  description text,
  icon text,
  sort_order integer not null default 0,
  is_visible boolean not null default true,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists languages (
  id bigserial primary key,
  name varchar(100) unique not null,
  level varchar(100),
  proficiency smallint,
  sort_order integer not null default 0,
  is_visible boolean not null default true,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists lab_items (
  id bigserial primary key,
  title varchar(255) not null,
  description text,
  progress smallint not null default 0,
  status varchar(32) not null default 'in_progress' check (status in ('idea','in_progress','paused','done')),
  url text,
  started_at date,
  updated_progress_at date,
  sort_order integer not null default 0,
  is_visible boolean not null default true,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists blog_posts (
  id bigserial primary key,
  title varchar(255) not null,
  slug varchar(255) unique not null,
  description text,
  content text,
  image_data text,
  image_url text,
  published_at timestamptz null,
  is_published boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists thought_posts (
  id bigserial primary key,
  title varchar(255) not null,
  slug varchar(255) unique not null,
  description text,
  content text,
  published_at timestamptz null,
  is_published boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists site_settings (
  id bigserial primary key,
  key varchar(120) unique not null,
  value text,
  type varchar(20) not null default 'text',
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists contact_messages (
  id bigserial primary key,
  type varchar(32) not null check (type in ('hiring','contract','question')),
  title varchar(180) not null,
  name varchar(120),
  email varchar(255) not null,
  message text not null,
  admin_reply text,
  replied_at timestamptz null,
  status varchar(32) not null default 'new',
  ip_hash varchar(255),
  created_at timestamptz null,
  updated_at timestamptz null
);

create table if not exists ai_requests (
  id bigserial primary key,
  session_id varchar(120),
  name varchar(120),
  email varchar(255),
  prompt text not null,
  response text,
  status varchar(32) not null default 'pending',
  duration_ms integer,
  metadata jsonb,
  ip_hash varchar(255),
  created_at timestamptz null,
  updated_at timestamptz null
);
