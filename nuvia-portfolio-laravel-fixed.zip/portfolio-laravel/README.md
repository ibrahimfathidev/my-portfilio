# Nuvia Portfolio — Laravel 13 + React + Supabase

This is a complete application source tree for the portfolio described in the notebook/photo. It is designed around Laravel 13, React + Inertia, PostgreSQL/Supabase, and a Cloudflare Worker AI endpoint. Laravel 13 is the current major release as of October 2026 and supports PHP 8.3–8.5. The official Laravel starter kits also support React + Inertia for authenticated applications. See the framework release notes and starter-kit docs for current upstream details.

## Included

- Open-source and closed-source projects with title, thumbnail, live URL and GitHub URL.
- Social links: Facebook, LinkedIn, Wattpad, Reddit, YouTube.
- Achievements: certificates, competitions, and hackathons.
- “How I Think”: problem solving, architecture, ERD and flow-chart artifacts.
- Stack: PHP, Laravel, React, Node.js, Next.js, Python, automation, web scraping, PostgreSQL.
- Integrations: Brevo, Supabase, Vercel, Netlify, Cloudflare, PWA.
- LAB: current projects and progress percentages.
- Daily Blog with title, description, photo as URL or `data:image/...;base64,...`.
- Languages with level/proficiency.
- Nuvia AI chat: Laravel proxies requests to a Cloudflare Worker and stores request/response history for admin review.
- Contact form for hiring, contract, or a question; messages are stored in the database and can be replied to from the admin dashboard.
- Admin dashboard with authentication, rate-limited login, generic CRUD editing for every CMS table, message inbox, and AI request log.
- PWA manifest + service worker.
- A PostgreSQL `database/schema.sql` matching the migrations.

## Important security note

The credentials included in your message should be treated as exposed. Do not put them in source control. Rotate the Supabase database password and any Supabase/API credentials before production, then put the replacements only in `.env` or your deployment secret manager. The generated project intentionally uses placeholders instead of copying the supplied secrets into code.

## Install

Requirements: PHP 8.3+, Composer, Node.js 20+ recommended, and a PostgreSQL/Supabase database.

```bash
cp .env.example .env
composer install
php artisan key:generate
npm install
```

Configure `.env`:

```env
APP_URL=https://your-domain.example
DB_CONNECTION=pgsql
DB_HOST=your-project.supabase.co
DB_PORT=5432
DB_DATABASE=postgres
DB_USERNAME=postgres
DB_PASSWORD=your-rotated-password
DB_SSLMODE=require

ADMIN_EMAIL=you@example.com
ADMIN_PASSWORD=a-long-random-admin-password

AI_WORKER_URL=https://your-worker.workers.dev/
AI_WORKER_TIMEOUT=25

MAIL_MAILER=smtp
MAIL_HOST=smtp.example.com
MAIL_PORT=587
MAIL_USERNAME=...
MAIL_PASSWORD=...
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=hello@example.com
MAIL_FROM_NAME="Nuvia"
```

Then:

```bash
php artisan migrate --seed
npm run build
php artisan serve
```

The admin login is at `/admin/login`. The seeder creates the admin account only when `ADMIN_EMAIL` and a real `ADMIN_PASSWORD` are present.

## Development

```bash
npm run dev
php artisan serve
```

## AI worker contract

The backend POSTs JSON like:

```json
{
  "message": "How does this project use Supabase?",
  "email": "visitor@example.com",
  "source": "portfolio"
}
```

The response parser accepts `response`, `message`, or `text` fields. Keep the Worker URL private to the server-side environment and do not expose it as a public frontend environment variable.

## Contact/reply flow

`POST /contact` stores the visitor message. The admin dashboard can change its status and send a reply using the configured mailer. The message itself stays in PostgreSQL even when outbound email delivery fails.

## Database schema

The canonical schema is the Laravel migration set under `database/migrations/`. `database/schema.sql` is provided for direct Supabase/PostgreSQL inspection or manual bootstrap. The main tables are:

`users`, `projects`, `project_artifacts`, `social_links`, `achievements`, `stacks`, `integrations`, `languages`, `lab_items`, `blog_posts`, `thought_posts`, `site_settings`, `contact_messages`, `ai_requests`.

## Suggested deployment layout

Use Laravel for the web app and server-side secrets, Supabase PostgreSQL for data, and Cloudflare in front of the app. Point the public domain at the Laravel deployment, set `APP_URL`, enable HTTPS, and keep database/API secrets on the server only.

## Source tree

```text
app/
  Http/Controllers/
  Http/Middleware/
  Mail/
  Models/
  Services/
bootstrap/
config/
database/
  migrations/
  seeders/
  schema.sql
public/
  manifest.webmanifest
  sw.js
resources/
  css/app.css
  js/
    Components/
    Layouts/
    Pages/
    app.tsx
routes/
  web.php
```
